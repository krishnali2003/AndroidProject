package com.example.greeting_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edited;
    Button button;
    TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edited = findViewById(R.id.editText1);
        button= findViewById(R.id.button1);
        title= findViewById(R.id.title);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text = edited.getText().toString();

                Toast.makeText(
                        MainActivity.this,
                        "Welcome"+" " + text,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}





