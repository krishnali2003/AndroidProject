package com.example.unitconverterapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    TextView text1;
    EditText edit1;
    Button button1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = findViewById(R.id.text2);
        edit1 = findViewById(R.id.editText);
        button1 = findViewById(R.id.btn);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = edit1.getText().toString();
                double kilos = Double.parseDouble(inputText);
                double pounds = makeConversion(kilos);
                text1.setText(" "+pounds);



            }

        });
    }

    public double makeConversion(double kilos){
        return kilos * 2.20462;
    }
}