package com.example.luckynumberapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button btn;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the views
        editText = findViewById(R.id.edit);
        btn = findViewById(R.id.button);
        txt = findViewById(R.id.textView1);

        // Set a click listener on the button
        btn.setOnClickListener(v -> {
            // Get the input from the EditText
            String s = editText.getText().toString();
            // Create an Intent to start the SecondActivity
            Intent i = new Intent(MainActivity.this, SecondActivity.class);
            // Pass the input text to the SecondActivity
            i.putExtra("name", s);
            // Start the SecondActivity
            startActivity(i);
        });
    }
}
