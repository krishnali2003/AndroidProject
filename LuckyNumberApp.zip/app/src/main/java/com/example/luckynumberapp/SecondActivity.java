package com.example.luckynumberapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button share = findViewById(R.id.button2);
        TextView welcome = findViewById(R.id.textView);
        TextView lucky = findViewById(R.id.textView2);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        int random6 = random1();
        lucky.setText(String.valueOf(random6));

        // Optionally set a welcome message
        welcome.setText("Welcome, " + name + "! Your lucky number is:");

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareData(name, random6);
            }
        });
    }

    public int random1() {
        Random random = new Random();
        int upper = 1000;
        return random.nextInt(upper);
    }

    public void shareData(String name, int random6) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,  name + ", your lucky number is ");
        i.putExtra(Intent.EXTRA_TEXT, "His lucky number is :"+random6);
        startActivity(Intent.createChooser(i, "Share via"));

    }
}
